# Modern C++ features

It's allowed to use in Firebird internal code C++ features up to and including C++17.

Public files (as API headers) is limited to C++11.

Exceptions to these rules should be listed below and must be agreed by the team,
discussing in the devel list or by pull request.

## Allowed features

### C++20
